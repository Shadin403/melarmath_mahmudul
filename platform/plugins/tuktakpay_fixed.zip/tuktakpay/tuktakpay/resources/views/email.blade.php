<strong>{{ trans('plugins/tuktakpay::tuktakpay.payment_details') }}: </strong>

@include('plugins/tuktakpay::detail', compact('payment'))