<ul>
    @foreach($payments->payments as $payment)
        <li>
            @include('plugins/tuktakpay::detail', compact('payment'))
        </li>
    @endforeach
</ul>