<ol>
    <li>
        <p> Create a TukTakPay Merchant Account
            <a href="https://tuktakpay.com" target="_blank">
              more info: https://tuktakpay.com
            </a>
        </p>
    </li>
    <li>
        <p>After creating your account, you will get:</p>
        <ul>
            <li>API Key</li>
        </ul>
    </li>
    <li class="pt-4">
        <p>{{ __('Enter your API key into the box on the right') }}</p>
    </li>
</ol>