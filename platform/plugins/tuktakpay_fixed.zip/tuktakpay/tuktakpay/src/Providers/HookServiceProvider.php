<?php

namespace TukTak\TukTakPay\Providers;

use Botble\Base\Facades\Html;
use Botble\Payment\Enums\PaymentMethodEnum;
use Botble\Payment\Facades\PaymentMethods;
use Illuminate\Http\Request;
use Illuminate\Support\ServiceProvider;
use TukTak\TukTakPay\Forms\TukTakPaymentMethodForm;
use TukTak\TukTakPay\Services\Gateways\TukTakPayPaymentService;

class HookServiceProvider extends ServiceProvider
{
    public function boot(): void
    {
        add_filter(PAYMENT_FILTER_ADDITIONAL_PAYMENT_METHODS, [$this, 'registerTukTakPayMethod'], 2, 2);

        $this->app->booted(function () {
            add_filter(PAYMENT_FILTER_AFTER_POST_CHECKOUT, [$this, 'checkoutWithTukTakPay'], 2, 2);
        });

        add_filter(PAYMENT_METHODS_SETTINGS_PAGE, [$this, 'addPaymentSettings'], 2);

        add_filter(BASE_FILTER_ENUM_ARRAY, function ($values, $class) {
            if ($class == PaymentMethodEnum::class) {
                $values['TUKTAKPAY'] = TUKTAKPAY_PAYMENT_METHOD_NAME;
            }

            return $values;
        }, 2, 2);

        add_filter(BASE_FILTER_ENUM_LABEL, function ($value, $class) {
            if ($class == PaymentMethodEnum::class && $value == TUKTAKPAY_PAYMENT_METHOD_NAME) {
                $value = 'TukTakPay';
            }

            return $value;
        }, 2, 2);

        add_filter(BASE_FILTER_ENUM_HTML, function ($value, $class) {
            if ($class == PaymentMethodEnum::class && $value == TUKTAKPAY_PAYMENT_METHOD_NAME) {
                $value = Html::tag(
                    'span',
                    PaymentMethodEnum::getLabel($value),
                    ['class' => 'label-success status-label']
                )
                    ->toHtml();
            }

            return $value;
        }, 2, 2);

        add_filter(PAYMENT_FILTER_GET_SERVICE_CLASS, function ($data, $value) {
            if ($value == TUKTAKPAY_PAYMENT_METHOD_NAME) {
                $data = TukTakPayPaymentService::class;
            }

            return $data;
        }, 2, 2);
    }

    public function addPaymentSettings(?string $settings): string
    {
        return $settings . TukTakPaymentMethodForm::create()->renderForm();
    }

    public function registerTukTakPayMethod(?string $html, array $data): string
    {
        PaymentMethods::method(TUKTAKPAY_PAYMENT_METHOD_NAME, [
            'html' => view('plugins/tuktakpay::methods', $data)->render(),
        ]);

        return $html;
    }

    public function checkoutWithTukTakPay(array $data, Request $request): array
    {
        if ($request->input('payment_method') == TUKTAKPAY_PAYMENT_METHOD_NAME) {
            $tukTakPayService = $this->app->make(TukTakPayPaymentService::class);

            $paymentData = apply_filters(PAYMENT_FILTER_PAYMENT_DATA, [], $request);

            $checkoutUrl = $tukTakPayService->makePayment($paymentData);

            if (isset($checkoutUrl['error'])) {
                $data['error'] = true;
                $data['message'] = $checkoutUrl['message'] ?? __('Payment failed. Please try again.');
            } else {
                $data['checkoutUrl'] = $checkoutUrl;
            }

            return $data;
        }

        return $data;
    }
}