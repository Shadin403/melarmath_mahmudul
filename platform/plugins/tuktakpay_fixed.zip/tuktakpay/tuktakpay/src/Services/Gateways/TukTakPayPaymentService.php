<?php

namespace TukTak\TukTakPay\Services\Gateways;

use Botble\Ecommerce\Models\Order;
use Botble\Payment\Enums\PaymentStatusEnum;
use Botble\Payment\Supports\PaymentHelper;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class TukTakPayPaymentService
{
    protected string $apiKey;
    protected string $webhookSecret;
    protected int $maxRetries = 3;
    protected int $retryDelay = 1; // seconds

    public function __construct()
    {
        $this->apiKey = setting('payment_tuktakpay_api_key');
        $this->webhookSecret = setting('payment_tuktakpay_webhook_secret', '');
    }

    protected function checkCredentials(): ?array
    {
        if (empty($this->apiKey)) {
            return [
                'error' => true,
                'message' => 'API key not configured. Please contact administrator.',
            ];
        }

        return null;
    }

    public function makePayment(array $data)
    {
        $credentialCheck = $this->checkCredentials();
        if ($credentialCheck) {
            return $credentialCheck;
        }

        $order = $data['orders'][0] ?? null;
        if (!$order) {
            return [
                'error' => true,
                'message' => 'Order not found',
            ];
        }

        // Ensure shipping method is set to prevent ShippingMethodEnum error
        if (empty($order->shipping_method)) {
            $order->shipping_method = 'default';
            $order->save();
        }

        $payload = [
            "cus_name" => $order->address->name ?? 'Customer',
            "cus_email" => $order->address->email ?? 'customer@example.com',
            "amount" => $data['amount'],
            "webhook_url" => route('payments.tuktakpay.webhook'),
            "success_url" => route('payments.tuktakpay.callback', [
                'payment_id' => '{{payment_id}}',
                'order_id' => $order->id,
                'status' => 'success'
            ]),
            "cancel_url" => PaymentHelper::getCancelURL(),
            "order_id" => $order->id, // Include order ID in payment creation
            "currency" => $data['currency'] ?? 'USD',
        ];

        Log::info('TukTakPay payment creation request', [
            'order_id' => $order->id,
            'amount' => $data['amount'],
            'currency' => $data['currency'] ?? 'USD'
        ]);

        $response = $this->makeApiRequest(
            'https://pay.xpresspay.cam/api/payment/create',
            $payload
        );

        if (isset($response['payment_url'])) {
            Log::info('TukTakPay payment URL generated', [
                'order_id' => $order->id,
                'payment_url' => $response['payment_url']
            ]);
            return $response['payment_url'];
        }

        Log::error('TukTakPay payment creation failed', [
            'order_id' => $order->id,
            'response' => $response
        ]);

        return [
            'error' => true,
            'message' => $response['message'] ?? 'Payment initiation failed',
        ];
    }

    public function verifyPayment(string $paymentId)
    {
        Log::info('TukTakPay payment verification started', ['payment_id' => $paymentId]);

        $response = $this->makeApiRequest(
            'https://pay.xpresspay.cam/api/payment/verify',
            ['payment_id' => $paymentId]
        );

        if (isset($response['error'])) {
            Log::error('TukTakPay payment verification failed', [
                'payment_id' => $paymentId,
                'error' => $response['error']
            ]);
        } else {
            Log::info('TukTakPay payment verification completed', [
                'payment_id' => $paymentId,
                'status' => $response['status'] ?? 'unknown'
            ]);
        }

        return $response;
    }

    public function validateWebhookSignature(Request $request): bool
    {
        // If no webhook secret is configured, skip signature validation
        if (empty($this->webhookSecret)) {
            Log::warning('TukTakPay webhook signature validation skipped - no secret configured');
            return true;
        }

        $signature = $request->header('X-TukTakPay-Signature');
        if (!$signature) {
            Log::error('TukTakPay webhook signature missing');
            return false;
        }

        $payload = $request->getContent();
        $expectedSignature = hash_hmac('sha256', $payload, $this->webhookSecret);

        if (!hash_equals($expectedSignature, $signature)) {
            Log::error('TukTakPay webhook signature mismatch', [
                'expected' => $expectedSignature,
                'received' => $signature
            ]);
            return false;
        }

        return true;
    }

    public function afterMakePayment(array $data, array $response): string
    {
        $order = Order::query()->find($data['order_id']);
        if ($order === null) {
            Log::error('TukTakPay afterMakePayment: Order not found', ['order_id' => $data['order_id']]);
            throw new \Exception('Order not found');
        }

        // Check if payment is already processed to prevent duplicate processing
        if ($order->status === 'completed') {
            Log::info('TukTakPay payment already processed', ['order_id' => $data['order_id']]);
            return $data['charge_id'];
        }

        $customer = $order->user;
        
        Log::info('TukTakPay processing payment completion', [
            'order_id' => $data['order_id'],
            'charge_id' => $data['charge_id'],
            'amount' => $data['amount'],
            'customer_id' => $customer->id ?? null
        ]);

        try {
            do_action(PAYMENT_ACTION_PAYMENT_PROCESSED, [
                'amount' => $data['amount'],
                'currency' => $data['currency'] ?? 'USD',
                'charge_id' => $data['charge_id'],
                'order_id' => $order->id,
                'customer_id' => $customer->id ?? null,
                'customer_type' => $customer ? get_class($customer) : null,
                'payment_channel' => TUKTAKPAY_PAYMENT_METHOD_NAME,
                'status' => PaymentStatusEnum::COMPLETED,
            ]);

            Log::info('TukTakPay payment processed successfully', [
                'order_id' => $data['order_id'],
                'charge_id' => $data['charge_id']
            ]);

        } catch (\Exception $e) {
            Log::error('TukTakPay payment processing failed', [
                'order_id' => $data['order_id'],
                'charge_id' => $data['charge_id'],
                'error' => $e->getMessage()
            ]);
            throw $e;
        }

        return $data['charge_id'];
    }

    public function getToken(array $data)
    {
        $order = Order::find($data['order_id']);
        
        if (!$order) {
            Log::error('TukTakPay getToken: Order not found', ['order_id' => $data['order_id']]);
            throw new \Exception('Order not found');
        }

        return $order->token;
    }

    public function supportedCurrencyCodes(): array
    {
        return ['USD', 'BDT'];
    }

    protected function makeApiRequest(string $url, array $data)
    {
        $headers = [
            'Content-Type' => 'application/json',
            'API-KEY' => $this->apiKey,
        ];

        $attempt = 0;
        $lastException = null;

        while ($attempt < $this->maxRetries) {
            $attempt++;
            
            try {
                Log::info('TukTakPay API request attempt', [
                    'url' => $url,
                    'attempt' => $attempt,
                    'data' => array_merge($data, ['API-KEY' => '[REDACTED]'])
                ]);

                $response = Http::withHeaders($headers)
                    ->timeout(30)
                    ->retry(2, 1000) // Built-in retry with 1 second delay
                    ->post($url, $data);

                if ($response->successful()) {
                    $result = $response->json();
                    Log::info('TukTakPay API request successful', [
                        'url' => $url,
                        'attempt' => $attempt,
                        'status_code' => $response->status()
                    ]);
                    return $result;
                }

                $errorMessage = $response->json()['message'] ?? 'HTTP ' . $response->status();
                Log::warning('TukTakPay API request failed', [
                    'url' => $url,
                    'attempt' => $attempt,
                    'status_code' => $response->status(),
                    'error' => $errorMessage
                ]);

                if ($response->status() >= 400 && $response->status() < 500) {
                    // Client error - don't retry
                    return [
                        'error' => true,
                        'message' => $errorMessage,
                        'status_code' => $response->status()
                    ];
                }

                // Server error - retry
                $lastException = new \Exception($errorMessage);

            } catch (\Exception $e) {
                Log::error('TukTakPay API request exception', [
                    'url' => $url,
                    'attempt' => $attempt,
                    'error' => $e->getMessage()
                ]);
                $lastException = $e;
            }

            if ($attempt < $this->maxRetries) {
                sleep($this->retryDelay * $attempt); // Exponential backoff
            }
        }

        Log::error('TukTakPay API request failed after all retries', [
            'url' => $url,
            'attempts' => $this->maxRetries,
            'last_error' => $lastException ? $lastException->getMessage() : 'Unknown error'
        ]);

        return [
            'error' => true,
            'message' => $lastException ? $lastException->getMessage() : 'API request failed after retries',
        ];
    }
}