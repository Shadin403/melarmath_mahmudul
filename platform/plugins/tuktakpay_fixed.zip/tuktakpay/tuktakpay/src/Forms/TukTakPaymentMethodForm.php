<?php

namespace TukTak\TukTakPay\Forms;

use Botble\Base\Facades\BaseHelper;
use Botble\Base\Forms\FieldOptions\CheckboxFieldOption;
use Botble\Base\Forms\FieldOptions\TextFieldOption;
use Botble\Base\Forms\Fields\OnOffCheckboxField;
use Botble\Base\Forms\Fields\TextField;
use Botble\Payment\Forms\PaymentMethodForm;

class TukTakPaymentMethodForm extends PaymentMethodForm
{
    public function setup(): void
    {
        parent::setup();

        $this
            ->paymentId(TUKTAKPAY_PAYMENT_METHOD_NAME)
            ->paymentName('TukTakPay')
            ->paymentDescription(__('Customer can buy product and pay with :name', ['name' => 'TukTakPay']))
            ->paymentLogo(url('vendor/core/plugins/tuktakpay/images/tuktakpay.png'))
            ->paymentUrl('https://tuktakpay.com')
            ->paymentInstructions(view('plugins/tuktakpay::settings')->render())
            ->add(
                sprintf('payment_%s_api_key', TUKTAKPAY_PAYMENT_METHOD_NAME),
                TextField::class,
                TextFieldOption::make()
                    ->label(__('API Key'))
                    ->value(BaseHelper::hasDemoModeEnabled() ? '*******************************' : get_payment_setting('api_key', TUKTAKPAY_PAYMENT_METHOD_NAME))
                    ->toArray()
            )
            ->add(
                sprintf('payment_%s_status', TUKTAKPAY_PAYMENT_METHOD_NAME),
                OnOffCheckboxField::class,
                CheckboxFieldOption::make()
                    ->label(trans('core/base::forms.status'))
                    ->value(get_payment_setting('status', TUKTAKPAY_PAYMENT_METHOD_NAME, false))
                    ->toArray()
            );
    }
}