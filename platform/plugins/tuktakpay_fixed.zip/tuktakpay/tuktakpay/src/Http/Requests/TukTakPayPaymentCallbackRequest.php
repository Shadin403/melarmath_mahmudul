<?php

namespace TukTak\TukTakPay\Http\Requests;

use Botble\Support\Http\Requests\Request;

class TukTakPayPaymentCallbackRequest extends Request
{
    public function rules(): array
    {
        return [
            'payment_id' => 'required|string|max:255',
            'order_id' => 'required|integer|exists:ec_orders,id',
            'status' => 'sometimes|string|in:success,failed,cancelled,pending',
        ];
    }

    public function messages(): array
    {
        return [
            'payment_id.required' => 'Payment ID is required',
            'payment_id.string' => 'Payment ID must be a string',
            'payment_id.max' => 'Payment ID cannot exceed 255 characters',
            'order_id.required' => 'Order ID is required',
            'order_id.integer' => 'Order ID must be an integer',
            'order_id.exists' => 'Order does not exist',
            'status.in' => 'Invalid payment status',
        ];
    }

    public function authorize(): bool
    {
        // Additional authorization logic can be added here
        return true;
    }
}