<?php

namespace TukTak\TukTakPay\Http\Controllers;

use Botble\Base\Http\Responses\BaseHttpResponse;
use Botble\Ecommerce\Models\Order;
use Botble\Payment\Supports\PaymentHelper;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\Log;
use TukTak\TukTakPay\Http\Requests\TukTakPayPaymentCallbackRequest;
use TukTak\TukTakPay\Services\Gateways\TukTakPayPaymentService;

class TukTakPayController extends Controller
{
    public function getCallback(TukTakPayPaymentCallbackRequest $request, TukTakPayPaymentService $tukTakPayPaymentService, BaseHttpResponse $response)
    {
        try {
            $paymentId = $request->input('payment_id');
            $orderId = $request->input('order_id');
            
            Log::info('TukTakPay callback received', [
                'payment_id' => $paymentId,
                'order_id' => $orderId,
                'status' => $request->input('status')
            ]);

            // Validate order exists and is pending
            $order = Order::find($orderId);
            if (!$order) {
                Log::error('TukTakPay callback: Order not found', ['order_id' => $orderId]);
                return $response
                    ->setError()
                    ->setNextUrl(PaymentHelper::getCancelURL())
                    ->setMessage(__('Order not found!'));
            }

            // Verify payment with TukTakPay API
            $status = $tukTakPayPaymentService->verifyPayment($paymentId);
            
            if (!$status || isset($status['error'])) {
                Log::error('TukTakPay payment verification failed', [
                    'payment_id' => $paymentId,
                    'order_id' => $orderId,
                    'error' => $status['error'] ?? 'Unknown error'
                ]);
                
                return $response
                    ->setError()
                    ->setNextUrl(PaymentHelper::getCancelURL())
                    ->setMessage(__('Payment verification failed!'));
            }

            // Check payment status
            if (!isset($status['status']) || $status['status'] !== 'COMPLETED') {
                Log::warning('TukTakPay payment not completed', [
                    'payment_id' => $paymentId,
                    'order_id' => $orderId,
                    'status' => $status['status'] ?? 'unknown'
                ]);
                
                return $response
                    ->setError()
                    ->setNextUrl(PaymentHelper::getCancelURL())
                    ->setMessage(__('Payment not completed!'));
            }

            // Validate payment amount matches order amount
            $expectedAmount = number_format($order->amount, 2, '.', '');
            $paidAmount = number_format($status['amount'] ?? 0, 2, '.', '');
            
            if ($expectedAmount !== $paidAmount) {
                Log::error('TukTakPay amount mismatch', [
                    'payment_id' => $paymentId,
                    'order_id' => $orderId,
                    'expected_amount' => $expectedAmount,
                    'paid_amount' => $paidAmount
                ]);
                
                return $response
                    ->setError()
                    ->setNextUrl(PaymentHelper::getCancelURL())
                    ->setMessage(__('Payment amount mismatch!'));
            }

            // Process successful payment
            $chargeId = $tukTakPayPaymentService->afterMakePayment([
                'amount' => $status['amount'],
                'currency' => $status['currency'] ?? 'USD',
                'charge_id' => $paymentId,
                'order_id' => $orderId,
            ], $status);

            Log::info('TukTakPay payment processed successfully', [
                'payment_id' => $paymentId,
                'order_id' => $orderId,
                'charge_id' => $chargeId,
                'amount' => $status['amount']
            ]);

            $token = $tukTakPayPaymentService->getToken([
                'order_id' => $orderId
            ]);

            return $response
                ->setNextUrl(PaymentHelper::getRedirectURL($token))
                ->setMessage(__('Payment completed successfully!'));

        } catch (\Exception $e) {
            Log::error('TukTakPay callback exception', [
                'payment_id' => $request->input('payment_id'),
                'order_id' => $request->input('order_id'),
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);

            return $response
                ->setError()
                ->setNextUrl(PaymentHelper::getCancelURL())
                ->setMessage(__('Payment processing failed!'));
        }
    }

    public function handleWebhook(Request $request, TukTakPayPaymentService $tukTakPayPaymentService)
    {
        try {
            $payload = $request->all();
            
            Log::info('TukTakPay webhook received', $payload);

            // Validate required fields
            if (!isset($payload['payment_id']) || !isset($payload['order_id'])) {
                Log::error('TukTakPay webhook: Missing required fields', $payload);
                return response()->json(['status' => 'error', 'message' => 'Missing required fields'], 400);
            }

            // Validate webhook signature if available
            if (!$tukTakPayPaymentService->validateWebhookSignature($request)) {
                Log::error('TukTakPay webhook: Invalid signature', $payload);
                return response()->json(['status' => 'error', 'message' => 'Invalid signature'], 401);
            }

            // Validate order exists
            $order = Order::find($payload['order_id']);
            if (!$order) {
                Log::error('TukTakPay webhook: Order not found', ['order_id' => $payload['order_id']]);
                return response()->json(['status' => 'error', 'message' => 'Order not found'], 404);
            }

            // Check if payment is already processed
            if ($order->status === 'completed') {
                Log::info('TukTakPay webhook: Payment already processed', ['order_id' => $payload['order_id']]);
                return response()->json(['status' => 'success', 'message' => 'Already processed']);
            }

            // Verify payment status
            if (!isset($payload['status']) || $payload['status'] !== 'COMPLETED') {
                Log::warning('TukTakPay webhook: Invalid payment status', [
                    'order_id' => $payload['order_id'],
                    'status' => $payload['status'] ?? 'unknown'
                ]);
                return response()->json(['status' => 'error', 'message' => 'Invalid payment status'], 400);
            }

            // Double-check with API verification
            $verificationResult = $tukTakPayPaymentService->verifyPayment($payload['payment_id']);
            if (!$verificationResult || $verificationResult['status'] !== 'COMPLETED') {
                Log::error('TukTakPay webhook: API verification failed', [
                    'payment_id' => $payload['payment_id'],
                    'verification_result' => $verificationResult
                ]);
                return response()->json(['status' => 'error', 'message' => 'Payment verification failed'], 400);
            }

            // Validate payment amount
            $expectedAmount = number_format($order->amount, 2, '.', '');
            $paidAmount = number_format($payload['amount'] ?? 0, 2, '.', '');
            
            if ($expectedAmount !== $paidAmount) {
                Log::error('TukTakPay webhook: Amount mismatch', [
                    'order_id' => $payload['order_id'],
                    'expected_amount' => $expectedAmount,
                    'paid_amount' => $paidAmount
                ]);
                return response()->json(['status' => 'error', 'message' => 'Amount mismatch'], 400);
            }

            // Process payment
            $chargeId = $tukTakPayPaymentService->afterMakePayment([
                'amount' => $payload['amount'],
                'currency' => $payload['currency'] ?? 'USD',
                'charge_id' => $payload['payment_id'],
                'order_id' => $payload['order_id'],
            ], $payload);

            Log::info('TukTakPay webhook processed successfully', [
                'payment_id' => $payload['payment_id'],
                'order_id' => $payload['order_id'],
                'charge_id' => $chargeId,
                'amount' => $payload['amount']
            ]);

            return response()->json(['status' => 'success']);

        } catch (\Exception $e) {
            Log::error('TukTakPay webhook exception', [
                'payload' => $request->all(),
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);

            return response()->json(['status' => 'error', 'message' => 'Internal server error'], 500);
        }
    }
}