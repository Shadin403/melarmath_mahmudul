<?php

if (!defined('TUKTAKPAY_PAYMENT_METHOD_NAME')) {
    define('TUKTAKPAY_PAYMENT_METHOD_NAME', 'tuktakpay');
}