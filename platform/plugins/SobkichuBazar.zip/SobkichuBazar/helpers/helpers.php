<?php

if (!defined('SobkichuBazar_PAYMENT_METHOD_NAME')) {
    define('SobkichuBazar_PAYMENT_METHOD_NAME', 'SobkichuBazar');
}