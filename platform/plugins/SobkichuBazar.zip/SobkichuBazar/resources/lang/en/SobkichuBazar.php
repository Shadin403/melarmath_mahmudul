<?php

return [
    'name' => 'SobkichuBazar',
    'payment_via_SobkichuBazar' => 'Payment via SobkichuBazar',
    'payment_details' => 'SobkichuBazar payment details',
    'api_key' => 'API Key',
    'api_key_placeholder' => 'Enter your SobkichuBazar API key',
    'description' => 'Pay securely through SobkichuBazar payment gateway',
];