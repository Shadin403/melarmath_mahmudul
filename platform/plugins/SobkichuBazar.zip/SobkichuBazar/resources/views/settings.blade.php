<ol>
    <li>
        <p> Create a SobkichuBazar Merchant Account
            <a href="https://sobkichubazar.com.bd" target="_blank">
              more info: https://sobkichubazar.com.bd
            </a>
        </p>
    </li>
    <li>
        <p>After creating your account, you will get:</p>
        <ul>
            <li>API Key</li>
        </ul>
    </li>
    <li class="pt-4">
        <p>{{ __('Enter your API key into the box on the right') }}</p>
    </li>
</ol>