<strong>{{ trans('plugins/SobkichuBazar::SobkichuBazar.payment_details') }}: </strong>

@include('plugins/SobkichuBazar::detail', compact('payment'))