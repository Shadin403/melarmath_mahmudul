<?php

namespace Sobkichu\SobkichuBazar\Http\Requests;

use Botble\Support\Http\Requests\Request;

class SobkichuBazarPaymentCallbackRequest extends Request
{
    public function rules(): array
    {
        return [
            'payment_id' => 'required|string',
            'order_id' => 'required|string',
            'status' => 'sometimes|string',
        ];
    }
}