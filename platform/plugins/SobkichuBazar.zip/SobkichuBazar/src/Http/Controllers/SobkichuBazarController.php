<?php

namespace Sobkichu\SobkichuBazar\Http\Controllers;

use Botble\Base\Http\Responses\BaseHttpResponse;
use Botble\Payment\Supports\PaymentHelper;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Sobkichu\SobkichuBazar\Http\Requests\SobkichuBazarPaymentCallbackRequest;
use Sobkichu\SobkichuBazar\Services\Gateways\SobkichuBazarPaymentService;

class SobkichuBazarController extends Controller
{
    public function getCallback(SobkichuBazarPaymentCallbackRequest $request, SobkichuBazarPaymentService $SobkichuBazarPaymentService, BaseHttpResponse $response)
    {
        $status = $SobkichuBazarPaymentService->verifyPayment($request->input('payment_id'));

        if (!isset($status['status']) || $status['status'] !== 'COMPLETED') {
            return $response
                ->setError()
                ->setNextUrl(PaymentHelper::getCancelURL())
                ->withInput()
                ->setMessage(__('Payment failed!'));
        }

        $SobkichuBazarPaymentService->afterMakePayment([
            'amount' => $status['amount'],
            'currency' => $status['currency'] ?? 'USD',
            'charge_id' => $request->input('payment_id'),
            'order_id' => $request->input('order_id'),
        ], $status);

        $token = $SobkichuBazarPaymentService->getToken([
            'order_id' => $request->input('order_id')
        ]);

        return $response
            ->setNextUrl(PaymentHelper::getRedirectURL($token))
            ->setMessage(__('Checkout successfully!'));
    }

    public function handleWebhook(Request $request, SobkichuBazarPaymentService $SobkichuBazarPaymentService)
    {
        $payload = $request->all();
        
        if (!isset($payload['status']) || $payload['status'] !== 'COMPLETED') {
            return response()->json(['status' => 'error', 'message' => 'Invalid payment status'], 400);
        }

        $SobkichuBazarPaymentService->afterMakePayment([
            'amount' => $payload['amount'],
            'currency' => $payload['currency'] ?? 'USD',
            'charge_id' => $payload['payment_id'],
            'order_id' => $payload['order_id'],
        ], $payload);

        return response()->json(['status' => 'success']);
    }
}