<?php

namespace Sobkichu\SobkichuBazar\Providers;

use Botble\Base\Facades\Html;
use Botble\Payment\Enums\PaymentMethodEnum;
use Botble\Payment\Facades\PaymentMethods;
use Illuminate\Http\Request;
use Illuminate\Support\ServiceProvider;
use Sobkichu\SobkichuBazar\Forms\SobkichuBazarmentMethodForm;
use Sobkichu\SobkichuBazar\Services\Gateways\SobkichuBazarPaymentService;

class HookServiceProvider extends ServiceProvider
{
    public function boot(): void
    {
        add_filter(PAYMENT_FILTER_ADDITIONAL_PAYMENT_METHODS, [$this, 'registerSobkichuBazarMethod'], 2, 2);

        $this->app->booted(function () {
            add_filter(PAYMENT_FILTER_AFTER_POST_CHECKOUT, [$this, 'checkoutWithSobkichuBazar'], 2, 2);
        });

        add_filter(PAYMENT_METHODS_SETTINGS_PAGE, [$this, 'addPaymentSettings'], 2);

        add_filter(BASE_FILTER_ENUM_ARRAY, function ($values, $class) {
            if ($class == PaymentMethodEnum::class) {
                $values['SobkichuBazar'] = SobkichuBazar_PAYMENT_METHOD_NAME;
            }

            return $values;
        }, 2, 2);

        add_filter(BASE_FILTER_ENUM_LABEL, function ($value, $class) {
            if ($class == PaymentMethodEnum::class && $value == SobkichuBazar_PAYMENT_METHOD_NAME) {
                $value = 'SobkichuBazar';
            }

            return $value;
        }, 2, 2);

        add_filter(BASE_FILTER_ENUM_HTML, function ($value, $class) {
            if ($class == PaymentMethodEnum::class && $value == SobkichuBazar_PAYMENT_METHOD_NAME) {
                $value = Html::tag(
                    'span',
                    PaymentMethodEnum::getLabel($value),
                    ['class' => 'label-success status-label']
                )
                    ->toHtml();
            }

            return $value;
        }, 2, 2);

        add_filter(PAYMENT_FILTER_GET_SERVICE_CLASS, function ($data, $value) {
            if ($value == SobkichuBazar_PAYMENT_METHOD_NAME) {
                $data = SobkichuBazarPaymentService::class;
            }

            return $data;
        }, 2, 2);
    }

    public function addPaymentSettings(?string $settings): string
    {
        return $settings . SobkichuBazarmentMethodForm::create()->renderForm();
    }

    public function registerSobkichuBazarMethod(?string $html, array $data): string
    {
        PaymentMethods::method(SobkichuBazar_PAYMENT_METHOD_NAME, [
            'html' => view('plugins/SobkichuBazar::methods', $data)->render(),
        ]);

        return $html;
    }

    public function checkoutWithSobkichuBazar(array $data, Request $request): array
    {
        if ($request->input('payment_method') == SobkichuBazar_PAYMENT_METHOD_NAME) {
            $SobkichuBazarService = $this->app->make(SobkichuBazarPaymentService::class);

            $paymentData = apply_filters(PAYMENT_FILTER_PAYMENT_DATA, [], $request);

            $checkoutUrl = $SobkichuBazarService->makePayment($paymentData);

            if (isset($checkoutUrl['error'])) {
                $data['error'] = true;
                $data['message'] = $checkoutUrl['message'] ?? __('Payment failed. Please try again.');
            } else {
                $data['checkoutUrl'] = $checkoutUrl;
            }

            return $data;
        }

        return $data;
    }
}