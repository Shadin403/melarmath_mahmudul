<?php

use Illuminate\Support\Facades\Route;
use Sobkichu\SobkichuBazar\Http\Controllers\SobkichuBazarController;

Route::group(['controller' => SobkichuBazarController::class, 'middleware' => ['web', 'core']], function () {
    Route::get('payment/SobkichuBazar/callback', 'getCallback')->name('payments.SobkichuBazar.callback');
    Route::post('payment/SobkichuBazar/webhook', 'handleWebhook')->name('payments.SobkichuBazar.webhook');
});