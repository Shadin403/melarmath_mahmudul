<?php

return [
    'name' => 'SobkichuBazarPay',
    'description' => 'SobkichuBazar Payment Gateway',
    'api_key' => 'API Key',
    'secret_key' => 'Secret Key',
    'brand_key' => 'Brand Key',
    'payment_success' => 'Payment completed successfully',
    'payment_failed' => 'Payment failed',
    'payment_cancelled' => 'Payment was cancelled',
    'payment_details' => 'Payment Details',
    'payment_via_sobkichubazarpay' => 'Payment via SobkichuBazarPay',
];

