<strong>{{ trans('plugins/sobkichubazarpay::sobkichubazarpay.payment_details') }}: </strong>

@include('plugins/sobkichubazarpay::detail', compact('payment'))

