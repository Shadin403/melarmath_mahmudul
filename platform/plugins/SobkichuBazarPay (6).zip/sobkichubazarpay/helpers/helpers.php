<?php

if (! defined('SOBKICHUBAZARPAY_PAYMENT_METHOD_NAME')) {
    define('SOBKICHUBAZARPAY_PAYMENT_METHOD_NAME', 'sobkichubazarpay');
}

