<?php

use Illuminate\Support\Facades\Route;
use TukTak\TukTakPay\Http\Controllers\TukTakPayController;

Route::group(['controller' => TukTakPayController::class, 'middleware' => ['web', 'core']], function () {
    Route::get('payment/tuktakpay/callback', 'getCallback')->name('payments.tuktakpay.callback');
    Route::post('payment/tuktakpay/webhook', 'handleWebhook')->name('payments.tuktakpay.webhook');
});