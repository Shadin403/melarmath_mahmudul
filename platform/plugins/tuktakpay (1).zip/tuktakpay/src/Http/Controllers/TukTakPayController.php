<?php

namespace TukTak\TukTakPay\Http\Controllers;

use Botble\Base\Http\Responses\BaseHttpResponse;
use Botble\Payment\Supports\PaymentHelper;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use TukTak\TukTakPay\Http\Requests\TukTakPayPaymentCallbackRequest;
use TukTak\TukTakPay\Services\Gateways\TukTakPayPaymentService;

class TukTakPayController extends Controller
{
    public function getCallback(TukTakPayPaymentCallbackRequest $request, TukTakPayPaymentService $tukTakPayPaymentService, BaseHttpResponse $response)
    {
        $status = $tukTakPayPaymentService->verifyPayment($request->input('payment_id'));

        if (!isset($status['status']) || $status['status'] !== 'COMPLETED') {
            return $response
                ->setError()
                ->setNextUrl(PaymentHelper::getCancelURL())
                ->withInput()
                ->setMessage(__('Payment failed!'));
        }

        $tukTakPayPaymentService->afterMakePayment([
            'amount' => $status['amount'],
            'currency' => $status['currency'] ?? 'USD',
            'charge_id' => $request->input('payment_id'),
            'order_id' => $request->input('order_id'),
        ], $status);

        $token = $tukTakPayPaymentService->getToken([
            'order_id' => $request->input('order_id')
        ]);

        return $response
            ->setNextUrl(PaymentHelper::getRedirectURL($token))
            ->setMessage(__('Checkout successfully!'));
    }

    public function handleWebhook(Request $request, TukTakPayPaymentService $tukTakPayPaymentService)
    {
        $payload = $request->all();
        
        if (!isset($payload['status']) || $payload['status'] !== 'COMPLETED') {
            return response()->json(['status' => 'error', 'message' => 'Invalid payment status'], 400);
        }

        $tukTakPayPaymentService->afterMakePayment([
            'amount' => $payload['amount'],
            'currency' => $payload['currency'] ?? 'USD',
            'charge_id' => $payload['payment_id'],
            'order_id' => $payload['order_id'],
        ], $payload);

        return response()->json(['status' => 'success']);
    }
}