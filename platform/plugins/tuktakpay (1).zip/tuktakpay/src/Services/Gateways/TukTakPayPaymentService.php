<?php

namespace TukTak\TukTakPay\Services\Gateways;

use Botble\Ecommerce\Models\Order;
use Botble\Payment\Enums\PaymentStatusEnum;
use Botble\Payment\Supports\PaymentHelper;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;

class TukTakPayPaymentService
{
    protected string $apiKey;

    public function __construct()
    {
        $this->apiKey = setting('payment_tuktakpay_api_key');
    }

    protected function checkCredentials(): ?array
    {
        if (empty($this->apiKey)) {
            return [
                'error' => true,
                'message' => 'API key not configured. Please contact administrator.',
            ];
        }

        return null;
    }

    public function makePayment(array $data)
    {
        $credentialCheck = $this->checkCredentials();
        if ($credentialCheck) {
            return $credentialCheck;
        }

        $order = $data['orders'][0] ?? null;
        if (!$order) {
            return [
                'error' => true,
                'message' => 'Order not found',
            ];
        }

        // Ensure shipping method is set to prevent ShippingMethodEnum error
        if (empty($order->shipping_method)) {
            $order->shipping_method = 'default';
            $order->save();
        }

        $payload = [
            "cus_name" => $order->address->name ?? 'Customer',
            "cus_email" => $order->address->email ?? 'customer@example.com',
            "amount" => $data['amount'],
            "webhook_url" => route('payments.tuktakpay.webhook'),
            "success_url" => route('payments.tuktakpay.callback', [
                'payment_id' => '{{payment_id}}',
                'order_id' => $order->id,
                'status' => 'success'
            ]),
            "cancel_url" => PaymentHelper::getCancelURL(),
        ];

        $response = $this->makeApiRequest(
            'https://pay.xpresspay.cam/api/payment/create',
            $payload
        );

        if (isset($response['payment_url'])) {
            return $response['payment_url'];
        }

        return [
            'error' => true,
            'message' => $response['message'] ?? 'Payment initiation failed',
        ];
    }

    public function verifyPayment(string $paymentId)
    {
        return $this->makeApiRequest(
            'https://pay.xpresspay.cam/api/payment/verify',
            ['payment_id' => $paymentId]
        );
    }

    public function afterMakePayment(array $data, array $response): string
    {
        $order = Order::query()->find($data['order_id']);
        if ($order !== null) {
            $customer = $order->user;
            do_action(PAYMENT_ACTION_PAYMENT_PROCESSED, [
                'amount' => $data['amount'],
                'currency' => $data['currency'] ?? 'USD',
                'charge_id' => $data['charge_id'],
                'order_id' => $order->id,
                'customer_id' => $customer->id ?? null,
                'customer_type' => $customer ? get_class($customer) : null,
                'payment_channel' => TUKTAKPAY_PAYMENT_METHOD_NAME,
                'status' => PaymentStatusEnum::COMPLETED,
            ]);
        }

        return $data['charge_id'];
    }

    public function getToken(array $data)
    {
        $order = Order::find($data['order_id']);

        return $order->token;
    }

    public function supportedCurrencyCodes(): array
    {
        return ['USD', 'BDT'];
    }

    protected function makeApiRequest(string $url, array $data)
    {
        $headers = [
            'Content-Type' => 'application/json',
            'API-KEY' => $this->apiKey,
        ];

        $response = Http::withHeaders($headers)
            ->timeout(30)
            ->post($url, $data);

        return $response->json();
    }
}