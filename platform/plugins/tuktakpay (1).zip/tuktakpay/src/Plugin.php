<?php

namespace TukTak\TukTakPay;

use Botble\PluginManagement\Abstracts\PluginOperationAbstract;
use Botble\Setting\Models\Setting;

class Plugin extends PluginOperationAbstract
{
    public static function remove(): void
    {
        Setting::query()
            ->whereIn('key', [
                'payment_tuktakpay_name',
                'payment_tuktakpay_description',
                'payment_tuktakpay_api_key',
                'payment_tuktakpay_status',
            ])
            ->delete();
    }
}