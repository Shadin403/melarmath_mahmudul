<?php

return [
    'name' => 'TukTakPay',
    'payment_via_tuktakpay' => 'Payment via TukTakPay',
    'payment_details' => 'TukTakPay payment details',
    'api_key' => 'API Key',
    'api_key_placeholder' => 'Enter your TukTakPay API key',
    'description' => 'Pay securely through TukTakPay payment gateway',
];