<?php

namespace Khairulkabir\BkashPay\Http\Requests;

use Botble\Support\Http\Requests\Request;

class BkashPayPaymentCallbackRequest extends Request
{
    public function rules(): array
    {
        return [];
    }
}
