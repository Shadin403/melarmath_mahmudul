<ol>
    <li>
        <p> Create an Bkash Merchant Account
            <a href="https://www.bkash.com/en/business/merchant" target="_blank">
              more info  https://www.bkash.com/en/business/merchant
            </a>
        </p>
        <p>After Creating  Merchant Account goto this url for
            <a href="https://pgw-integration.bkash.com/#/merchant/signin" target="_blank">
                sign UP
            </a>

        </p>
    </li>
    <li>
        <p>After sign up. Login in. then get you</p>
        <ul>
            <li>Username</li>
            <li>Password</li>
            <li>App key</li>
            <li>App Secret Key</li>
        </ul>

    </li>
    <li class="pt-4">
        <p>{{ __('Enter all into into the box in right hand') }}</p>
    </li>
</ol>

