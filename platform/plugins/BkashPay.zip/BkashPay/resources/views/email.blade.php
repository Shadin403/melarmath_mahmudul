<strong>{{ trans('plugins/bkashpay::bkashpay.payment_details') }}: </strong>

@include('plugins/bkashpay::detail', compact('payment'))
