<?php

if (! defined('BKASHPAY_PAYMENT_METHOD_NAME')) {
    define('BKASHPAY_PAYMENT_METHOD_NAME', 'bkashpay');
}
